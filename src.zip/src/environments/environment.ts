
export const environment = {
  production: false,
  pokemonURL: 'https://pokeapi.co/api/v2/pokemon',
  pokemonSpeciesURL: 'https://pokeapi.co/api/v2/pokemon-species'
};


